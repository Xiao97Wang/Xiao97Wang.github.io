/*
 * Comment to state the purpose of this program (filename.cpp)
 */
#include<iostream>
#include <fstream>   /*output to a txt file*/
#include <cmath>
#include <complex>
using namespace std;

const complex<double> xj(0.0,1.0);
const double pi=M_PI;  // 3.14159265358979
double om=0.1;
double bt=2000.0;
double vf=4.2;
double A0=0.01;
double g=-vf*A0*sqrt(2.0);

int m;
int k;   
int n;
int i;
int j;

complex<double> s;
complex<double> s1;
complex<double> t;
complex<double> tempg;
complex<double> temperraa;
complex<double> temperrab;
complex<double> temperrba;
complex<double> temperrbb;
double maxerr=0.001;

const int ku=320;  //upper-boundary of array
const int nu=20000;
double kr=0.2; //upper-boundary of k in real scale
complex<double> gaa[ku][nu];
complex<double> gab[ku][nu];
complex<double> gba[ku][nu];
complex<double> gbb[ku][nu];
complex<double> selfaa[ku][nu];
complex<double> selfbb[ku][nu];

double p(int n)
{
	return pi*(-nu*1.+2.*n+1.)/bt;    //recalibrate the origin of the frequency number
}

double k_real_scale(int k)
{
	return 2.*kr*k/(ku*1.-1.)-kr;    //recalibrate k
}

complex<double> gaa_0(int k, int n)
{
	s1=-xj*p(n);
	s1/=p(n)*p(n)+k_real_scale(k)*k_real_scale(k)*vf*vf;
	return s1;
}

complex<double> gbb_0(int k, int n)
{
	s1=-xj*p(n);
	s1/=p(n)*p(n)+k_real_scale(k)*k_real_scale(k)*vf*vf;
	return s1;
}

complex<double> gab_0(int k, int n)
{
	s1=-k_real_scale(k)*vf;
	s1/=p(n)*p(n)+k_real_scale(k)*k_real_scale(k)*vf*vf;
	return s1;
}

complex<double> gba_0(int k, int n)
{
	s1=-k_real_scale(k)*vf;
	s1/=p(n)*p(n)+k_real_scale(k)*k_real_scale(k)*vf*vf;
	return s1;
}


//compare with analytical result
complex<double> nb(complex<double> om)
{
	return 1.0/(exp(bt*om)-1.0);
}

complex<double> ana_selfbb(int k, int n)
{
	s=(-om+xj*p(n))*(-om+xj*p(n));
	s-=vf*vf*k_real_scale(k)*k_real_scale(k);
	t=(-om+xj*p(n))*nb(-om)/s;
	t+=0.5*nb(-xj*p(n)+k_real_scale(k)*vf)/(om-xj*p(n)+k_real_scale(k)*vf);
	t+=0.5*nb(-xj*p(n)-k_real_scale(k)*vf)/(om-xj*p(n)-k_real_scale(k)*vf);

	return -1.0*g*g*t;
}


int main ()
{

 	ofstream outFile;
    outFile.open("Matsubara self-energy.dat");

	outFile.precision(10);
	outFile.setf(ios_base::showpoint);




//calculation is close in each k
for (k=0; k < ku; ++k)
 {

// for each (k,n) generate the initial green fuction

	for(j=0;j<nu;j++){
		gaa[k][j]=gaa_0(k, j);
		gab[k][j]=gab_0(k, j);
		gba[k][j]=gba_0(k, j);
		gbb[k][j]=gbb_0(k, j);
	}


 	cout<<"solving k="<<k_real_scale(k)<<"**************"<<endl;
	cout<<"iratation number:";
 	//loop to calculate self-consistency gf
int error=1;

while(error>0){
	// calculate self-energy at k in all pn
	n=0;
	while(n<nu){
		s=(0.0,0.0);
		t=(0.0,0.0);
		m=n-nu+1;
		while(m<=n){
			    // assume green function is 0 when n is far from 0
				// thus (n-m>=0 && n-m<nu)
			s+=(1./(-xj*2.*(m*1.)*pi/bt-om))*gbb[k][n-m];
			          //s+=(1./(xj*2.*(m*1.)*pi/bt-om))*gbb_0(k,n-m);   
			//here m is same as its real number
			//because "gaa[k][n-m]" here requires (n-m) correspond to real fermion frequency P(n-m) in a manner
			//P(n-m)=pi*(-nu*1.+2.*(n-m)+1.)/bt
			//while from the begining we also require n satisfy P(n)=pi*(-nu*1.+2.*(n)+1.)/bt
			//so boson frequency above is 2*m*pi/bt
			//	cout<<"m="<<m<<endl;
			//	cout<<"s+="<<(1./(m*m*1.+10.))*gaa[k][n-m]<<endl;
			t+=(1./(xj*2.*(m*1.)*pi/bt-om))*gaa[k][n-m];     //???there must be sth wrong********
			          //t+=(1./(xj*2.*(m*1.)*pi/bt-om))*gaa_0(k,n-m);
			m++;
		}
		selfaa[k][n]=-1.*g*g*s/bt;
		selfbb[k][n]=-1.*g*g*t/bt;
		//cout<<"selfaa at"<<k<<" "<<n<<"is"<<"s"<<s<<endl;
		//selfaa[k][n]=(0.,0.);
		//selfbb[k][n]=(0.,0.);

		n++;
	}

	//cout<<"finish self-energy**************************************"<<endl;
	//calculate gf using self-energy
	n=0;
	error=0;

	while(n<nu){

		t=(0.0,0.0);
		t+=1.;
		//cout<<"t="<<t<<endl;
		//cout<<"need to add"<<-((gbb_0(k, n)+gab_0(k, n)*gba_0(k, n)*selfaa[k][n])*selfbb[k][n])<<endl;
		t-=(gbb_0(k, n)+gab_0(k, n)*gba_0(k, n)*selfaa[k][n])*selfbb[k][n];
		//cout<<"t==="<<t<<endl;
		t+=gaa_0(k, n)*selfaa[k][n]*(-1.+gbb_0(k, n)*selfbb[k][n]);
		//cout<<"t====="<<t<<endl;
		s=(0.0,0.0);
		s+=gaa_0(k, n);
		s+=gab_0(k, n)*gba_0(k, n)*selfbb[k][n];
		s-=gaa_0(k, n)*gbb_0(k, n)*selfbb[k][n];
		//cout<<"t========="<<t<<endl;
		s/=t;
		tempg=gaa[k][n];
		//cout<<"tempgaa"<<tempg<<endl;
		gaa[k][n]=s;
		//cout<<"gaa[k][n]"<<gaa[k][n]<<endl;
		temperraa=gaa[k][n]-tempg;
		//cout<<"temperraa at n="<<n<<"is"<<temperraa<<endl;
			//calculate the discrepancy between two iritates
		
		//cout<<"t==================="<<t<<endl;
		s=(0.0,0.0);
		//cout<<"t============================="<<t<<endl;
		s+=gab_0(k, n);
		//cout<<"first step s="<<s<<endl;
		//cout<<"t======================================="<<t<<endl;
		//cout<<"s/t="<<s*conj(t)/(abs(t)*abs(t))<<endl;
		//s=s*conj(t)/(abs(t)*abs(t));
		s/=t;
		tempg=gab[k][n];
		gab[k][n]=s;
		//cout<<"gab is"<<s<<"from"<<tempg<<endl;
		temperrab=gab[k][n]-tempg;

		s=(0.0,0.0);
		s+=gba_0(k, n);
		s/=t;
		tempg=gba[k][n];
		gba[k][n]=s;
		temperrba=gba[k][n]-tempg;

		s=(0.0,0.0);
		s+=gbb_0(k, n);
		s+=gab_0(k, n)*gba_0(k, n)*selfaa[k][n];
		s-=gaa_0(k, n)*gbb_0(k, n)*selfaa[k][n];
		s/=t;
		tempg=gbb[k][n];
		gbb[k][n]=s;
		temperrbb=gbb[k][n]-tempg;



		if (abs(temperraa)+abs(temperrab)+abs(temperrba)+abs(temperrbb)>maxerr)
		{
			error=1;
			//cout<<" tot err= "<<abs(temperraa)+abs(temperrab)+abs(temperrba)+abs(temperrbb)<<" must iritate again"<<endl;
		}
	n++;
	}
	//error=0;  cout<<"try first order"<<endl;
cout<<"*";
}//end self-consistency calculation of GF at k
cout<<endl;
//	cout<<"k="<<k<<endl;
//	cout<<gaa[k][nu/2]<<gaa_0(k, nu/2)<<endl;
//	cout<<gab[k][nu/2]<<gab_0(k, nu/2)<<endl;
//	cout<<gba[k][nu/2]<<gba_0(k, nu/2)<<endl;
//	cout<<gbb[k][nu/2]<<gbb_0(k, nu/2)<<endl;



 	for (n = 0.475*nu; n < 0.525*nu; n+=20)   //pn should be seperated farther
 	{
		outFile<<k_real_scale(k)<<" "<<p(n)<<" "<<fixed<<" "<<selfaa[k][n].real()<<" "<<selfaa[k][n].imag()<<" "<<selfbb[k][n].real()<<" "<<selfbb[k][n].imag()<<endl;
		//outFile<<k_real_scale(k)<<" "<<p(n)<<" "<<fixed<<" "<<gab_0(k,n)<<endl;
	}


 }    //end loop of k


//draw the graph of Matsubara GF

	
	outFile.close();

//rotate xj*pn into real frequency ep


//output the spectrum in real scale  

return 0;
} 